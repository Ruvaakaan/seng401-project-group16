def update_bio(event, context):
  pass