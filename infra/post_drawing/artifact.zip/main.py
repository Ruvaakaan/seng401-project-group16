def post_drawing(event, context):
  pass