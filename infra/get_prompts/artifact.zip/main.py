def get_prompts(event, context):
  pass