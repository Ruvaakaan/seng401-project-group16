def un_like_drawing(event, context):
  pass